package com.bankapp.model.entity;

public enum TxType {
	WITHDRAW,DEPOSIT,TRANSFER;
}
