package com.bankapp.model.entity;

public enum AccountType {
		SAVING,CURRENT;
}
