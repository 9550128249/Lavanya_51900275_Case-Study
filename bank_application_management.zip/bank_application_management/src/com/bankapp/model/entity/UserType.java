package com.bankapp.model.entity;

public enum UserType {
		ADMIN,MANAGER,CLERK;
}
