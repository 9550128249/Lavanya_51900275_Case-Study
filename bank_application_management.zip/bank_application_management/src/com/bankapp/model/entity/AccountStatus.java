package com.bankapp.model.entity;

public enum AccountStatus {
	ACTIVE,SUSPEND,CLOSED;
}
